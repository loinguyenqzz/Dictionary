package sample;

public class Vocabulary {
    public String Vietnamese;
    public String English;
}
